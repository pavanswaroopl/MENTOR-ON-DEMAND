package com.iiht.authservice.exception;

public class UsernameNotFoundException {
	
	
	

}
