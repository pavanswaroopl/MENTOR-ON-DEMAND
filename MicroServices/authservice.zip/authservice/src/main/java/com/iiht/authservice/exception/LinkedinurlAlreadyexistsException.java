package com.iiht.authservice.exception;

public class LinkedinurlAlreadyexistsException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
